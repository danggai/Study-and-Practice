package com.example.rvtest

data class Song(val title: String, val content: String)