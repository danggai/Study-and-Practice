package com.example.rvtest

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertController.RecycleListView

class MainAdapter: RecycleListView.Adapter<MainAdapter.MainViewHolder>() {

    var items: MutableList<Song> = mutableListOf(Song("Malli Flower", "1"), Song("Halo", "2"), Song("Daddy", "3"))

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int) = MainViewHolder(parent)

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: MainAdapter.MainViewHolder, position: Int) {
        items[position].let { item ->
            with(holder) {
                tvlTitle.text = item.title
                tvlContent.text = item.content
            }
        }
    }

    inner class MainViewHolder(parent: ViewGroup) : RecycleListView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_main, parent, false)) {
        val tvlTitle = itemView.tv_main_title
        val tvlContent = itemView.tv_main_content
    }
}
